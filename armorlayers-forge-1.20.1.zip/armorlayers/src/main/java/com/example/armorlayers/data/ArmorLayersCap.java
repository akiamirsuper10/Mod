package com.example.armorlayers.data;

import com.example.armorlayers.ArmorLayers;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;

public final class ArmorLayersCap {
    public static final Capability<ArmorLayersData> CAP = CapabilityManager.get(new CapabilityToken<>() {});
    public static final ResourceLocation ID = new ResourceLocation(ArmorLayers.MODID, "layers");

    public static class Provider implements ICapabilitySerializable<CompoundTag> {
        private final ArmorLayersData data = new ArmorLayersData();
        private final LazyOptional<ArmorLayersData> holder = LazyOptional.of(() -> data);

        @Override
        public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
            return CAP.orEmpty(cap, holder);
        }

        @Override
        public CompoundTag serializeNBT() {
            return data.save();
        }

        @Override
        public void deserializeNBT(CompoundTag tag) {
            data.load(tag);
        }
    }

    private ArmorLayersCap() {}
}
