package com.example.armorlayers.client;

import com.example.armorlayers.ArmorLayers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidArmorModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ArmorLayers.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    /**
     * Раздувание модели брони слоёв 2 и 3. У ванильной брони: 1.0 (шлем, нагрудник, ботинки) и 0.5 (поножи).
     * Внешний слой скина (куртка, рукава) раздут на 0.25, поэтому 0.3 — минимум, чтобы он не торчал сквозь броню.
     * Хотите ровно «по скину» — поставьте 0.0 (но тогда внешний слой скина будет просвечивать).
     */
    public static final float SMALL_INFLATION = 0.3F;

    public static final ModelLayerLocation SMALL_INNER =
            new ModelLayerLocation(new ResourceLocation(ArmorLayers.MODID, "small_inner_armor"), "main");
    public static final ModelLayerLocation SMALL_OUTER =
            new ModelLayerLocation(new ResourceLocation(ArmorLayers.MODID, "small_outer_armor"), "main");

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        CubeDeformation deformation = new CubeDeformation(SMALL_INFLATION);
        event.registerLayerDefinition(SMALL_INNER,
                () -> LayerDefinition.create(HumanoidModel.createMesh(deformation, 0.0F), 64, 32));
        event.registerLayerDefinition(SMALL_OUTER,
                () -> LayerDefinition.create(HumanoidModel.createMesh(deformation, 0.0F), 64, 32));
    }

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        EntityModelSet models = event.getEntityModels();
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer == null) continue;
            renderer.addLayer(new SmallArmorLayer(
                    renderer,
                    new HumanoidArmorModel<AbstractClientPlayer>(models.bakeLayer(SMALL_INNER)),
                    new HumanoidArmorModel<AbstractClientPlayer>(models.bakeLayer(SMALL_OUTER)),
                    Minecraft.getInstance().getModelManager()));
        }
    }

    private ClientModEvents() {}
}
