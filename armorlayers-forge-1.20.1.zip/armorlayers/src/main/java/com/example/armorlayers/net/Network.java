package com.example.armorlayers.net;

import com.example.armorlayers.ArmorLayers;
import com.example.armorlayers.client.ClientHandlers;
import com.example.armorlayers.data.ArmorLayersData;
import com.example.armorlayers.menu.LayerLayout;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class Network {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ArmorLayers.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, SetActivePacket.class,
                SetActivePacket::encode, SetActivePacket::decode, SetActivePacket::handle);
        CHANNEL.registerMessage(id++, LayerSyncPacket.class,
                LayerSyncPacket::encode, LayerSyncPacket::decode, LayerSyncPacket::handle);
        CHANNEL.registerMessage(id++, DisplayPacket.class,
                DisplayPacket::encode, DisplayPacket::decode, DisplayPacket::handle);
    }

    /** Клиент -> сервер: включить защиту от слоя layer для части тела part. */
    public static class SetActivePacket {
        public final int part;
        public final int layer;

        public SetActivePacket(int part, int layer) {
            this.part = part;
            this.layer = layer;
        }

        public static void encode(SetActivePacket m, FriendlyByteBuf buf) {
            buf.writeByte(m.part);
            buf.writeByte(m.layer);
        }

        public static SetActivePacket decode(FriendlyByteBuf buf) {
            return new SetActivePacket(buf.readByte(), buf.readByte());
        }

        public static void handle(SetActivePacket m, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> {
                ServerPlayer player = c.getSender();
                if (player == null) return;
                ArmorLayersData data = ArmorLayersData.get(player);
                if (data != null) data.requestSwitch(player, m.part, m.layer);
            });
            c.setPacketHandled(true);
        }
    }

    /** Сервер -> владелец: активные слои и содержимое всех 12 логических слотов. */
    public static class LayerSyncPacket {
        public final int[] active;
        public final ItemStack[] items;

        public LayerSyncPacket(int[] active, ItemStack[] items) {
            this.active = active;
            this.items = items;
        }

        public static void encode(LayerSyncPacket m, FriendlyByteBuf buf) {
            for (int i = 0; i < LayerLayout.PARTS; i++) buf.writeByte(m.active[i]);
            for (int i = 0; i < LayerLayout.LAYERS * LayerLayout.PARTS; i++) buf.writeItem(m.items[i]);
        }

        public static LayerSyncPacket decode(FriendlyByteBuf buf) {
            int[] active = new int[LayerLayout.PARTS];
            for (int i = 0; i < active.length; i++) active[i] = buf.readByte();
            ItemStack[] items = new ItemStack[LayerLayout.LAYERS * LayerLayout.PARTS];
            for (int i = 0; i < items.length; i++) items[i] = buf.readItem();
            return new LayerSyncPacket(active, items);
        }

        public static void handle(LayerSyncPacket m, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientHandlers.layerSync(m.active, m.items)));
            c.setPacketHandled(true);
        }
    }

    /** Сервер -> все, кто видит игрока: какой самый высокий слой надо рисовать для каждой части. */
    public static class DisplayPacket {
        public final int entityId;
        public final ItemStack[] stacks;
        public final int[] layers;

        public DisplayPacket(int entityId, ItemStack[] stacks, int[] layers) {
            this.entityId = entityId;
            this.stacks = stacks;
            this.layers = layers;
        }

        public static void encode(DisplayPacket m, FriendlyByteBuf buf) {
            buf.writeVarInt(m.entityId);
            for (int i = 0; i < LayerLayout.PARTS; i++) {
                buf.writeItem(m.stacks[i]);
                buf.writeByte(m.layers[i]);
            }
        }

        public static DisplayPacket decode(FriendlyByteBuf buf) {
            int id = buf.readVarInt();
            ItemStack[] stacks = new ItemStack[LayerLayout.PARTS];
            int[] layers = new int[LayerLayout.PARTS];
            for (int i = 0; i < LayerLayout.PARTS; i++) {
                stacks[i] = buf.readItem();
                layers[i] = buf.readByte();
            }
            return new DisplayPacket(id, stacks, layers);
        }

        public static void handle(DisplayPacket m, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientHandlers.display(m.entityId, m.stacks, m.layers)));
            c.setPacketHandled(true);
        }
    }

    private Network() {}
}
