package com.example.armorlayers.menu;

import com.mojang.datafixers.util.Pair;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

public class LayerSlot extends Slot {
    private static final ResourceLocation[] EMPTY_ICONS = {
            InventoryMenu.EMPTY_ARMOR_SLOT_HELMET,
            InventoryMenu.EMPTY_ARMOR_SLOT_CHESTPLATE,
            InventoryMenu.EMPTY_ARMOR_SLOT_LEGGINGS,
            InventoryMenu.EMPTY_ARMOR_SLOT_BOOTS
    };

    private final Player player;
    private final int layer;
    private final int part;

    public LayerSlot(LayerContainer container, Player player, int layer, int part) {
        super(container, layer * LayerLayout.PARTS + part, LayerLayout.slotX(layer), LayerLayout.slotY(part));
        this.player = player;
        this.layer = layer;
        this.part = part;
    }

    public int layer() {
        return layer;
    }

    public int part() {
        return part;
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return stack.canEquip(LayerLayout.SLOTS[part], player);
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }

    @Override
    public boolean mayPickup(Player picker) {
        ItemStack stack = getItem();
        if (!stack.isEmpty() && !picker.isCreative() && EnchantmentHelper.hasBindingCurse(stack)) {
            return false;
        }
        return super.mayPickup(picker);
    }

    @Override
    public Pair<ResourceLocation, ResourceLocation> getNoItemIcon() {
        return Pair.of(InventoryMenu.BLOCK_ATLAS, EMPTY_ICONS[part]);
    }

    /** Слои 2 и 3 видны только когда открыто обычное окно инвентаря и закрыта книга рецептов. */
    @Override
    public boolean isActive() {
        return layer == 0 || ClientState.panelVisible;
    }
}
