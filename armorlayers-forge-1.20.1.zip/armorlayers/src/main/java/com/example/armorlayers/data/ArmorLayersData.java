package com.example.armorlayers.data;

import com.example.armorlayers.menu.LayerLayout;
import com.example.armorlayers.net.Network;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraftforge.network.PacketDistributor;

import java.util.Arrays;
import java.util.List;

/**
 * Данные слоёв брони игрока.
 *
 * Идея: для каждой части тела предмет АКТИВНОГО слоя лежит в обычном ванильном слоте брони
 * (поэтому защита, прочность, зачарования, атрибуты и другие моды работают как в ваниле),
 * а предметы остальных слоёв хранятся здесь. Инвариант: stored[active[part]][part] всегда пуст.
 */
public class ArmorLayersData {
    private static final int LAYERS = LayerLayout.LAYERS;
    private static final int PARTS = LayerLayout.PARTS;

    private final ItemStack[][] stored = new ItemStack[LAYERS][PARTS];
    private final int[] active = new int[PARTS];

    // --- состояние синхронизации (сервер) ---
    private final ItemStack[] lastFull = new ItemStack[LAYERS * PARTS];
    private final int[] lastActive = new int[PARTS];
    private final ItemStack[] lastDispStack = new ItemStack[PARTS];
    private final int[] lastDispLayer = new int[PARTS];
    private boolean dirty = true;

    // --- что рисовать на модели игрока (клиент) ---
    private final ItemStack[] dispStack = new ItemStack[PARTS];
    private final int[] dispLayer = new int[PARTS];
    private boolean hasDisplay = false;

    public ArmorLayersData() {
        for (ItemStack[] row : stored) Arrays.fill(row, ItemStack.EMPTY);
        Arrays.fill(lastFull, ItemStack.EMPTY);
        Arrays.fill(lastActive, -1);
        Arrays.fill(lastDispStack, ItemStack.EMPTY);
        Arrays.fill(lastDispLayer, -2);
        Arrays.fill(dispStack, ItemStack.EMPTY);
        Arrays.fill(dispLayer, -1);
    }

    public static ArmorLayersData get(Player player) {
        return player.getCapability(ArmorLayersCap.CAP).resolve().orElse(null);
    }

    // ------------------------------------------------------------------ доступ

    public int getActive(int part) {
        return active[part];
    }

    public ItemStack getStack(Player player, int layer, int part) {
        if (layer == active[part]) {
            return player.getInventory().armor.get(LayerLayout.armorIndex(part));
        }
        return stored[layer][part];
    }

    public void setStack(Player player, int layer, int part, ItemStack stack) {
        if (layer == active[part]) {
            player.getInventory().armor.set(LayerLayout.armorIndex(part), stack);
        } else {
            stored[layer][part] = stack;
        }
    }

    // ------------------------------------------------------------------ логика слоёв

    /** Меняет активный слой: предмет из ванильного слота уходит в хранилище, новый встаёт на его место. */
    public void switchActive(Player player, int part, int newLayer) {
        int old = active[part];
        if (old == newLayer) return;
        NonNullList<ItemStack> armor = player.getInventory().armor;
        int idx = LayerLayout.armorIndex(part);

        ItemStack current = armor.get(idx);
        stored[old][part] = current.isEmpty() ? ItemStack.EMPTY : current;
        armor.set(idx, stored[newLayer][part]);
        stored[newLayer][part] = ItemStack.EMPTY;
        active[part] = newLayer;
    }

    /** Запрос игрока (с сервера): включить защиту от слоя layer для части part. */
    public boolean requestSwitch(ServerPlayer player, int part, int layer) {
        if (part < 0 || part >= PARTS || layer < 0 || layer >= LAYERS) return false;
        if (active[part] == layer) return false;
        if (getStack(player, layer, part).isEmpty()) return false;

        ItemStack current = getStack(player, active[part], part);
        if (!current.isEmpty() && !player.isCreative() && EnchantmentHelper.hasBindingCurse(current)) {
            return false; // проклятие несъёмности держит предмет
        }
        switchActive(player, part, layer);
        return true;
    }

    /** Если активный слой пуст, а в другом есть броня — переключаемся на самый высокий занятый слой. */
    public void autoSwitch(Player player) {
        NonNullList<ItemStack> armor = player.getInventory().armor;
        for (int part = 0; part < PARTS; part++) {
            if (!armor.get(LayerLayout.armorIndex(part)).isEmpty()) continue;
            for (int layer = 0; layer < LAYERS; layer++) {
                if (layer != active[part] && !stored[layer][part].isEmpty()) {
                    switchActive(player, part, layer);
                    break;
                }
            }
        }
    }

    /** Для каждой части — самый высокий (с наименьшим номером) непустой слой. */
    public void computeDisplay(Player player, ItemStack[] stacks, int[] layers) {
        for (int part = 0; part < PARTS; part++) {
            stacks[part] = ItemStack.EMPTY;
            layers[part] = -1;
            for (int layer = 0; layer < LAYERS; layer++) {
                ItemStack s = getStack(player, layer, part);
                if (!s.isEmpty()) {
                    stacks[part] = s;
                    layers[part] = layer;
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------------ сервер: тик и синхронизация

    public void markDirty() {
        dirty = true;
    }

    public void serverTick(ServerPlayer player) {
        if (!player.isAlive()) return;
        autoSwitch(player);

        // 1) полное состояние — владельцу
        boolean fullChanged = dirty;
        ItemStack[] cur = new ItemStack[LAYERS * PARTS];
        for (int i = 0; i < cur.length; i++) {
            cur[i] = getStack(player, i / PARTS, i % PARTS);
            if (!fullChanged && !same(cur[i], lastFull[i])) fullChanged = true;
        }
        for (int part = 0; part < PARTS; part++) {
            if (active[part] != lastActive[part]) fullChanged = true;
        }
        if (fullChanged) {
            ItemStack[] copies = new ItemStack[cur.length];
            for (int i = 0; i < cur.length; i++) {
                copies[i] = cur[i].copy();
                lastFull[i] = cur[i].copy();
            }
            System.arraycopy(active, 0, lastActive, 0, PARTS);
            Network.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new Network.LayerSyncPacket(active.clone(), copies));
        }

        // 2) что рисовать на модели — всем, кто видит игрока, и ему самому
        ItemStack[] ds = new ItemStack[PARTS];
        int[] dl = new int[PARTS];
        computeDisplay(player, ds, dl);
        boolean dispChanged = dirty;
        for (int part = 0; part < PARTS; part++) {
            if (dl[part] != lastDispLayer[part] || !same(ds[part], lastDispStack[part])) dispChanged = true;
        }
        if (dispChanged) {
            ItemStack[] copies = new ItemStack[PARTS];
            for (int part = 0; part < PARTS; part++) {
                copies[part] = ds[part].copy();
                lastDispStack[part] = ds[part].copy();
                lastDispLayer[part] = dl[part];
            }
            Network.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player),
                    new Network.DisplayPacket(player.getId(), copies, dl));
        }
        dirty = false;
    }

    /** Отправить данные для отрисовки игрока owner конкретному зрителю viewer (когда viewer начал его видеть). */
    public static void sendDisplay(ServerPlayer owner, ServerPlayer viewer) {
        ArmorLayersData data = get(owner);
        if (data == null) return;
        ItemStack[] ds = new ItemStack[PARTS];
        int[] dl = new int[PARTS];
        data.computeDisplay(owner, ds, dl);
        ItemStack[] copies = new ItemStack[PARTS];
        for (int part = 0; part < PARTS; part++) copies[part] = ds[part].copy();
        Network.CHANNEL.send(PacketDistributor.PLAYER.with(() -> viewer),
                new Network.DisplayPacket(owner.getId(), copies, dl));
    }

    private static boolean same(ItemStack a, ItemStack b) {
        if (a.isEmpty() && b.isEmpty()) return true;
        return ItemStack.matches(a, b);
    }

    // ------------------------------------------------------------------ клиент

    public void applyFull(Player player, int[] newActive, ItemStack[] logical) {
        NonNullList<ItemStack> armor = player.getInventory().armor;
        for (int part = 0; part < PARTS; part++) {
            active[part] = Mth.clamp(newActive[part], 0, LAYERS - 1);
        }
        for (int part = 0; part < PARTS; part++) {
            for (int layer = 0; layer < LAYERS; layer++) {
                ItemStack s = logical[layer * PARTS + part];
                if (layer == active[part]) {
                    armor.set(LayerLayout.armorIndex(part), s);
                    stored[layer][part] = ItemStack.EMPTY;
                } else {
                    stored[layer][part] = s;
                }
            }
        }
    }

    public void setDisplay(ItemStack[] stacks, int[] layers) {
        for (int part = 0; part < PARTS; part++) {
            dispStack[part] = stacks[part];
            dispLayer[part] = layers[part];
        }
        hasDisplay = true;
    }

    public boolean hasDisplay() {
        return hasDisplay;
    }

    public ItemStack getDispStack(int part) {
        return dispStack[part];
    }

    public int getDispLayer(int part) {
        return dispLayer[part];
    }

    // ------------------------------------------------------------------ смерть, копирование, NBT

    /** Забирает предметы неактивных слоёв (ванильные слоты выбросит сама игра). */
    public void collectAndClearStored(List<ItemStack> out) {
        for (int layer = 0; layer < LAYERS; layer++) {
            for (int part = 0; part < PARTS; part++) {
                if (!stored[layer][part].isEmpty()) {
                    out.add(stored[layer][part]);
                    stored[layer][part] = ItemStack.EMPTY;
                }
            }
        }
        dirty = true;
    }

    public void copyFrom(ArmorLayersData other) {
        for (int layer = 0; layer < LAYERS; layer++) {
            for (int part = 0; part < PARTS; part++) {
                stored[layer][part] = other.stored[layer][part].copy();
            }
        }
        System.arraycopy(other.active, 0, active, 0, PARTS);
        dirty = true;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putIntArray("Active", active.clone());
        ListTag list = new ListTag();
        for (int layer = 0; layer < LAYERS; layer++) {
            for (int part = 0; part < PARTS; part++) {
                ItemStack s = stored[layer][part];
                if (s.isEmpty()) continue;
                CompoundTag entry = new CompoundTag();
                entry.putByte("Layer", (byte) layer);
                entry.putByte("Part", (byte) part);
                entry.put("Item", s.save(new CompoundTag()));
                list.add(entry);
            }
        }
        tag.put("Items", list);
        return tag;
    }

    public void load(CompoundTag tag) {
        for (ItemStack[] row : stored) Arrays.fill(row, ItemStack.EMPTY);
        Arrays.fill(active, 0);

        int[] saved = tag.getIntArray("Active");
        for (int part = 0; part < PARTS && part < saved.length; part++) {
            active[part] = Mth.clamp(saved[part], 0, LAYERS - 1);
        }
        ListTag list = tag.getList("Items", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            int layer = entry.getByte("Layer");
            int part = entry.getByte("Part");
            if (layer < 0 || layer >= LAYERS || part < 0 || part >= PARTS) continue;
            if (layer == active[part]) continue; // инвариант: у активного слоя хранилище пусто
            stored[layer][part] = ItemStack.of(entry.getCompound("Item"));
        }
        dirty = true;
    }
}
