package com.example.armorlayers.common;

import com.example.armorlayers.ArmorLayers;
import com.example.armorlayers.data.ArmorLayersData;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ArmorLayers.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    @SubscribeEvent
    public static void registerCaps(RegisterCapabilitiesEvent event) {
        event.register(ArmorLayersData.class);
    }

    private ModEvents() {}
}
