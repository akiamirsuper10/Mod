package com.example.armorlayers.menu;

/** Флаг, который клиент выставляет каждый кадр: показывается ли панель слоёв 2 и 3. */
public final class ClientState {
    public static volatile boolean panelVisible = false;

    private ClientState() {}
}
