package com.example.armorlayers.common;

import com.example.armorlayers.ArmorLayers;
import com.example.armorlayers.data.ArmorLayersCap;
import com.example.armorlayers.data.ArmorLayersData;
import com.example.armorlayers.menu.MenuInstaller;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.GameRules;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = ArmorLayers.MODID)
public final class CommonEvents {

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(ArmorLayersCap.ID, new ArmorLayersCap.Provider());
        }
    }

    /** Переносим данные при смерти / возвращении из Энда. */
    @SubscribeEvent
    public static void clone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        try {
            ArmorLayersData from = ArmorLayersData.get(event.getOriginal());
            ArmorLayersData to = ArmorLayersData.get(event.getEntity());
            if (from != null && to != null) to.copyFrom(from);
        } finally {
            event.getOriginal().invalidateCaps();
        }
    }

    /** Встраиваем слоты в инвентарь игрока (и на клиенте, и на сервере). */
    @SubscribeEvent
    public static void join(EntityJoinLevelEvent event) {
        if (event.getEntity() instanceof Player player) {
            MenuInstaller.install(player);
        }
    }

    @SubscribeEvent
    public static void playerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        ArmorLayersData data = ArmorLayersData.get(player);
        if (data != null) data.serverTick(player);
    }

    /** При смерти без keepInventory выбрасываем и предметы неактивных слоёв. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void drops(LivingDropsEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().getGameRules().getBoolean(GameRules.RULE_KEEPINVENTORY)) return;
        ArmorLayersData data = ArmorLayersData.get(player);
        if (data == null) return;

        List<ItemStack> items = new ArrayList<>();
        data.collectAndClearStored(items);
        for (ItemStack stack : items) {
            if (EnchantmentHelper.hasVanishingCurse(stack)) continue;
            ItemEntity drop = new ItemEntity(player.level(), player.getX(), player.getY(), player.getZ(), stack);
            drop.setDefaultPickUpDelay();
            drop.setDeltaMovement(
                    player.getRandom().nextGaussian() * 0.05,
                    0.2,
                    player.getRandom().nextGaussian() * 0.05);
            event.getDrops().add(drop);
        }
    }

    @SubscribeEvent
    public static void startTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer target && event.getEntity() instanceof ServerPlayer viewer) {
            ArmorLayersData.sendDisplay(target, viewer);
        }
    }

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent event) {
        markDirty(event.getEntity());
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent event) {
        markDirty(event.getEntity());
    }

    @SubscribeEvent
    public static void changedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        markDirty(event.getEntity());
    }

    private static void markDirty(Player player) {
        ArmorLayersData data = ArmorLayersData.get(player);
        if (data != null) data.markDirty();
    }

    private CommonEvents() {}
}
