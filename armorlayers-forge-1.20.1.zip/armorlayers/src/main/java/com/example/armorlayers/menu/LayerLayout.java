package com.example.armorlayers.menu;

import net.minecraft.world.entity.EquipmentSlot;

/**
 * Общие константы раскладки. Часть тела (part): 0 = голова, 1 = грудь, 2 = ноги, 3 = ботинки.
 * Слой (layer): 0 = первый (самый высокий), 2 = третий (самый низкий).
 */
public final class LayerLayout {
    public static final int LAYERS = 3;
    public static final int PARTS = 4;

    public static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    // Панель слоёв 2 и 3 слева от окна инвентаря (координаты относительно левого верхнего угла окна)
    public static final int PANEL_X = -46;
    public static final int PANEL_Y = 4;
    public static final int PANEL_W = 44;
    public static final int PANEL_H = 79;

    // Кнопка выбора активного слоя в правом нижнем углу каждого слота
    public static final int BTN_OFFSET = 10;
    public static final int BTN_SIZE = 6;

    public static int slotX(int layer) {
        if (layer == 0) return 8;      // там, где в ванили стоят слоты брони
        if (layer == 1) return -21;
        return -41;
    }

    public static int slotY(int part) {
        return 8 + part * 18;
    }

    /** Индекс в Inventory.armor (0 = ботинки ... 3 = шлем). */
    public static int armorIndex(int part) {
        return SLOTS[part].getIndex();
    }

    private LayerLayout() {}
}
