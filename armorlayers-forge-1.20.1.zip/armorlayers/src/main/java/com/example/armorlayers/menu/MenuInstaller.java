package com.example.armorlayers.menu;

import com.example.armorlayers.data.ArmorLayersData;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;

import java.lang.reflect.Method;

/**
 * Встраивает слоты слоёв в ванильное InventoryMenu игрока (и на клиенте, и на сервере, в одном порядке):
 *  - слоты 5..8 (ванильная броня) заменяются на слот слоя 1;
 *  - слоты 46..53 добавляются для слоёв 2 и 3.
 */
public final class MenuInstaller {
    private static Method addSlotMethod;

    public static void install(Player player) {
        InventoryMenu menu = player.inventoryMenu;
        if (menu.slots.size() > 5 && menu.slots.get(5) instanceof LayerSlot) {
            return; // уже установлено (например, при смене измерения)
        }
        ArmorLayersData data = ArmorLayersData.get(player);
        if (data == null) return;

        LayerContainer container = new LayerContainer(player, data);

        for (int part = 0; part < LayerLayout.PARTS; part++) {
            LayerSlot slot = new LayerSlot(container, player, 0, part);
            slot.index = 5 + part;
            menu.slots.set(5 + part, slot);
        }
        for (int layer = 1; layer < LayerLayout.LAYERS; layer++) {
            for (int part = 0; part < LayerLayout.PARTS; part++) {
                addSlot(menu, new LayerSlot(container, player, layer, part));
            }
        }
    }

    /** AbstractContainerMenu.addSlot защищён; ищем его по сигнатуре (Slot) -> Slot, чтобы не зависеть от имён. */
    private static void addSlot(AbstractContainerMenu menu, Slot slot) {
        try {
            if (addSlotMethod == null) {
                for (Method m : AbstractContainerMenu.class.getDeclaredMethods()) {
                    if (m.getParameterCount() == 1
                            && m.getParameterTypes()[0] == Slot.class
                            && m.getReturnType() == Slot.class) {
                        m.setAccessible(true);
                        addSlotMethod = m;
                        break;
                    }
                }
            }
            if (addSlotMethod == null) {
                throw new IllegalStateException("AbstractContainerMenu.addSlot not found");
            }
            addSlotMethod.invoke(menu, slot);
        } catch (ReflectiveOperationException ex) {
            throw new RuntimeException("Failed to add armor layer slot", ex);
        }
    }

    private MenuInstaller() {}
}
