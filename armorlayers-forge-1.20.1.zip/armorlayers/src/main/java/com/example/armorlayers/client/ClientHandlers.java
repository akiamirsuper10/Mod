package com.example.armorlayers.client;

import com.example.armorlayers.data.ArmorLayersData;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Обработка пакетов на клиенте (вызывается через DistExecutor). */
public final class ClientHandlers {

    public static void layerSync(int[] active, ItemStack[] items) {
        Player player = Minecraft.getInstance().player;
        if (player == null) return;
        ArmorLayersData data = ArmorLayersData.get(player);
        if (data != null) data.applyFull(player, active, items);
    }

    public static void display(int entityId, ItemStack[] stacks, int[] layers) {
        Level level = Minecraft.getInstance().level;
        if (level == null) return;
        Entity entity = level.getEntity(entityId);
        if (entity instanceof Player player) {
            ArmorLayersData data = ArmorLayersData.get(player);
            if (data != null) data.setDisplay(stacks, layers);
        }
    }

    private ClientHandlers() {}
}
