package com.example.armorlayers.client;

import com.example.armorlayers.ArmorLayers;
import com.example.armorlayers.data.ArmorLayersData;
import com.example.armorlayers.menu.ClientState;
import com.example.armorlayers.menu.LayerLayout;
import com.example.armorlayers.menu.LayerSlot;
import com.example.armorlayers.net.Network;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ContainerScreenEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Интерфейс инвентаря: панель слева с слоями 2 и 3, кнопки выбора активного слоя у каждого слота
 * и ручная обработка кликов по слотам, которые лежат за пределами окна инвентаря.
 */
@Mod.EventBusSubscriber(modid = ArmorLayers.MODID, value = Dist.CLIENT)
public final class ClientGuiEvents {
    private static final ResourceLocation INVENTORY_TEX = InventoryScreen.INVENTORY_LOCATION;

    private static final int COLOR_ACTIVE = 0xFF55FF55;
    private static final int COLOR_IDLE = 0xFF8B8B8B;
    private static final int COLOR_EMPTY = 0xFF4A4A4A;
    private static final int COLOR_HOVER = 0xFFFFFFFF;

    // ------------------------------------------------------------------ состояние

    private static boolean isPanelScreen(Screen screen) {
        return screen instanceof InventoryScreen inv && !inv.getRecipeBookComponent().isVisible();
    }

    private static ArmorLayersData localData() {
        Player player = Minecraft.getInstance().player;
        return player == null ? null : ArmorLayersData.get(player);
    }

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        ClientState.panelVisible = isPanelScreen(Minecraft.getInstance().screen);
        ArmorRenderSwap.safetyRestore();
    }

    @SubscribeEvent
    public static void renderPre(ScreenEvent.Render.Pre event) {
        ClientState.panelVisible = isPanelScreen(event.getScreen());
    }

    // ------------------------------------------------------------------ отрисовка

    /** Панель и фон слотов слоёв 2 и 3 (рисуется до слотов). */
    @SubscribeEvent
    public static void renderBackground(ContainerScreenEvent.Render.Background event) {
        if (!(event.getContainerScreen() instanceof InventoryScreen screen) || !ClientState.panelVisible) return;
        GuiGraphics g = event.getGuiGraphics();
        int left = screen.getGuiLeft();
        int top = screen.getGuiTop();

        int x = left + LayerLayout.PANEL_X;
        int y = top + LayerLayout.PANEL_Y;
        int w = LayerLayout.PANEL_W;
        int h = LayerLayout.PANEL_H;
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFC6C6C6);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 2, y + h - 1, 0xFFFFFFFF);
        g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, 0xFF555555);
        g.fill(x + w - 2, y + 1, x + w - 1, y + h - 1, 0xFF555555);

        for (int layer = 1; layer < LayerLayout.LAYERS; layer++) {
            for (int part = 0; part < LayerLayout.PARTS; part++) {
                // спрайт обычного слота инвентаря из ванильной текстуры
                g.blit(INVENTORY_TEX,
                        left + LayerLayout.slotX(layer) - 1, top + LayerLayout.slotY(part) - 1,
                        7, 83, 18, 18);
            }
        }
    }

    /** Рамка активного слоя и кнопки (рисуются поверх предметов). Координаты относительно окна. */
    @SubscribeEvent
    public static void renderForeground(ContainerScreenEvent.Render.Foreground event) {
        if (!(event.getContainerScreen() instanceof InventoryScreen screen)) return;
        ArmorLayersData data = localData();
        Player player = Minecraft.getInstance().player;
        if (data == null || player == null) return;

        GuiGraphics g = event.getGuiGraphics();
        int hovered = buttonAt(screen, event.getMouseX(), event.getMouseY());

        g.pose().pushPose();
        g.pose().translate(0.0F, 0.0F, 300.0F);
        for (int layer = 0; layer < LayerLayout.LAYERS; layer++) {
            if (layer > 0 && !ClientState.panelVisible) continue;
            for (int part = 0; part < LayerLayout.PARTS; part++) {
                int sx = LayerLayout.slotX(layer);
                int sy = LayerLayout.slotY(part);
                boolean active = data.getActive(part) == layer;
                boolean empty = data.getStack(player, layer, part).isEmpty();

                if (active) {
                    g.renderOutline(sx - 1, sy - 1, 18, 18, COLOR_ACTIVE);
                }

                int bx = sx + LayerLayout.BTN_OFFSET;
                int by = sy + LayerLayout.BTN_OFFSET;
                int size = LayerLayout.BTN_SIZE;
                int color;
                if (active) color = COLOR_ACTIVE;
                else if (hovered == layer * LayerLayout.PARTS + part && !empty) color = COLOR_HOVER;
                else color = empty ? COLOR_EMPTY : COLOR_IDLE;

                g.fill(bx, by, bx + size, by + size, 0xFF000000);
                g.fill(bx + 1, by + 1, bx + size - 1, by + size - 1, color);
            }
        }
        g.pose().popPose();
    }

    /** Подсказка над кнопкой (рисуется после всего). */
    @SubscribeEvent
    public static void renderPost(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;
        int button = buttonAt(screen, event.getMouseX(), event.getMouseY());
        if (button < 0) return;

        ArmorLayersData data = localData();
        Player player = Minecraft.getInstance().player;
        if (data == null || player == null) return;

        int layer = button / LayerLayout.PARTS;
        int part = button % LayerLayout.PARTS;
        String key;
        if (data.getActive(part) == layer) key = "armorlayers.tooltip.active";
        else if (data.getStack(player, layer, part).isEmpty()) key = "armorlayers.tooltip.empty";
        else key = "armorlayers.tooltip.activate";

        event.getGuiGraphics().renderTooltip(Minecraft.getInstance().font,
                Component.translatable(key, layer + 1), event.getMouseX(), event.getMouseY());
    }

    // ------------------------------------------------------------------ клики

    @SubscribeEvent
    public static void mousePressed(ScreenEvent.MouseButtonPressed.Pre event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;
        int mouseButton = event.getButton();
        if (mouseButton != 0 && mouseButton != 1) return;

        Minecraft mc = Minecraft.getInstance();
        ArmorLayersData data = localData();
        if (data == null || mc.player == null || mc.gameMode == null) return;

        // 1) кнопка выбора активного слоя
        int button = buttonAt(screen, event.getMouseX(), event.getMouseY());
        if (button >= 0) {
            int layer = button / LayerLayout.PARTS;
            int part = button % LayerLayout.PARTS;
            if (mouseButton == 0 && data.getActive(part) != layer
                    && !data.getStack(mc.player, layer, part).isEmpty()) {
                Network.CHANNEL.sendToServer(new Network.SetActivePacket(part, layer));
                mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
            }
            event.setCanceled(true);
            return;
        }

        if (!ClientState.panelVisible) return;

        // 2) слоты слоёв 2 и 3 лежат за пределами окна — ванильный экран кликов по ним не обработает
        LayerSlot slot = slotAt(screen, event.getMouseX(), event.getMouseY());
        if (slot != null) {
            ClickType type = Screen.hasShiftDown() ? ClickType.QUICK_MOVE : ClickType.PICKUP;
            mc.gameMode.handleInventoryMouseClick(screen.getMenu().containerId, slot.index, mouseButton, type, mc.player);
            event.setCanceled(true);
            return;
        }

        // 3) клик по пустому месту панели не должен выбрасывать предмет с курсора
        if (inPanel(screen, event.getMouseX(), event.getMouseY())) {
            event.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ геометрия

    /** Возвращает layer * 4 + part для кнопки под курсором или -1. */
    private static int buttonAt(InventoryScreen screen, double mouseX, double mouseY) {
        double rx = mouseX - screen.getGuiLeft();
        double ry = mouseY - screen.getGuiTop();
        for (int layer = 0; layer < LayerLayout.LAYERS; layer++) {
            if (layer > 0 && !ClientState.panelVisible) continue;
            for (int part = 0; part < LayerLayout.PARTS; part++) {
                int bx = LayerLayout.slotX(layer) + LayerLayout.BTN_OFFSET;
                int by = LayerLayout.slotY(part) + LayerLayout.BTN_OFFSET;
                if (rx >= bx && rx < bx + LayerLayout.BTN_SIZE && ry >= by && ry < by + LayerLayout.BTN_SIZE) {
                    return layer * LayerLayout.PARTS + part;
                }
            }
        }
        return -1;
    }

    private static LayerSlot slotAt(InventoryScreen screen, double mouseX, double mouseY) {
        double rx = mouseX - screen.getGuiLeft();
        double ry = mouseY - screen.getGuiTop();
        for (Slot slot : screen.getMenu().slots) {
            if (slot instanceof LayerSlot layerSlot && layerSlot.layer() > 0) {
                if (rx >= slot.x && rx < slot.x + 16 && ry >= slot.y && ry < slot.y + 16) {
                    return layerSlot;
                }
            }
        }
        return null;
    }

    private static boolean inPanel(InventoryScreen screen, double mouseX, double mouseY) {
        double rx = mouseX - screen.getGuiLeft();
        double ry = mouseY - screen.getGuiTop();
        return rx >= LayerLayout.PANEL_X && rx < LayerLayout.PANEL_X + LayerLayout.PANEL_W
                && ry >= LayerLayout.PANEL_Y && ry < LayerLayout.PANEL_Y + LayerLayout.PANEL_H;
    }

    private ClientGuiEvents() {}
}
