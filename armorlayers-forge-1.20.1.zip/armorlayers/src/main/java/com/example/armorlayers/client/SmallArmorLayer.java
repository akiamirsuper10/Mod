package com.example.armorlayers.client;

import com.example.armorlayers.menu.LayerLayout;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidArmorModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.core.NonNullList;
import net.minecraft.world.item.ItemStack;

/**
 * Обычный ванильный слой брони, но с моделями без раздувания (размер почти как у скина).
 * Рисует предметы слоёв 2 и 3, которые ArmorRenderSwap подготовил в smallView.
 */
public class SmallArmorLayer extends HumanoidArmorLayer<AbstractClientPlayer,
        PlayerModel<AbstractClientPlayer>, HumanoidArmorModel<AbstractClientPlayer>> {

    public SmallArmorLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent,
                           HumanoidArmorModel<AbstractClientPlayer> inner,
                           HumanoidArmorModel<AbstractClientPlayer> outer,
                           ModelManager modelManager) {
        super(parent, inner, outer, modelManager);
        ArmorRenderSwap.probe = inner;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                       AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (ArmorRenderSwap.swapped != player || !ArmorRenderSwap.anySmall) return;

        NonNullList<ItemStack> armor = player.getInventory().armor;
        for (int part = 0; part < LayerLayout.PARTS; part++) {
            armor.set(LayerLayout.armorIndex(part), ArmorRenderSwap.smallView[part]);
        }
        try {
            super.render(poseStack, buffer, packedLight, player, limbSwing, limbSwingAmount,
                    partialTick, ageInTicks, netHeadYaw, headPitch);
        } finally {
            for (int part = 0; part < LayerLayout.PARTS; part++) {
                armor.set(LayerLayout.armorIndex(part), ArmorRenderSwap.vanillaView[part]);
            }
        }
    }
}
