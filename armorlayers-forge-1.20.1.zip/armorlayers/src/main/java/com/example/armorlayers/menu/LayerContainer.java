package com.example.armorlayers.menu;

import com.example.armorlayers.data.ArmorLayersData;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Контейнер из 12 логических слотов: индекс = слой * 4 + часть тела.
 * Предмет активного слоя физически лежит в ванильном слоте брони, остальные — в данных мода.
 */
public class LayerContainer implements Container {
    private final Player player;
    private final ArmorLayersData data;

    public LayerContainer(Player player, ArmorLayersData data) {
        this.player = player;
        this.data = data;
    }

    @Override
    public int getContainerSize() {
        return LayerLayout.LAYERS * LayerLayout.PARTS;
    }

    @Override
    public boolean isEmpty() {
        for (int i = 0; i < getContainerSize(); i++) {
            if (!getItem(i).isEmpty()) return false;
        }
        return true;
    }

    @Override
    public ItemStack getItem(int index) {
        return data.getStack(player, index / LayerLayout.PARTS, index % LayerLayout.PARTS);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack stack = getItem(index);
        if (stack.isEmpty() || count <= 0) return ItemStack.EMPTY;
        return stack.split(count);
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        ItemStack stack = getItem(index);
        setItem(index, ItemStack.EMPTY);
        return stack;
    }

    @Override
    public void setItem(int index, ItemStack stack) {
        data.setStack(player, index / LayerLayout.PARTS, index % LayerLayout.PARTS, stack);
    }

    @Override
    public void setChanged() {
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public void clearContent() {
        for (int i = 0; i < getContainerSize(); i++) {
            setItem(i, ItemStack.EMPTY);
        }
    }
}
