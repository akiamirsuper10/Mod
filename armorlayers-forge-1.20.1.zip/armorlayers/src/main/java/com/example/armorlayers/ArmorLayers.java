package com.example.armorlayers;

import com.example.armorlayers.net.Network;
import net.minecraftforge.fml.common.Mod;

@Mod(ArmorLayers.MODID)
public class ArmorLayers {
    public static final String MODID = "armorlayers";

    public ArmorLayers() {
        Network.register();
    }
}
