package com.example.armorlayers.client;

import com.example.armorlayers.ArmorLayers;
import com.example.armorlayers.data.ArmorLayersData;
import com.example.armorlayers.menu.LayerLayout;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Подмена брони на время отрисовки игрока (без миксинов).
 *
 * Перед отрисовкой в ванильные слоты брони кладётся то, что должно быть видно:
 *  - слой 1 и броня с собственной моделью из других модов — рисует обычный ванильный слой брони;
 *  - слои 2 и 3 (обычная броня) — рисует наш SmallArmorLayer уменьшенной моделью.
 * После отрисовки настоящие предметы возвращаются на место.
 */
@Mod.EventBusSubscriber(modid = ArmorLayers.MODID, value = Dist.CLIENT)
public final class ArmorRenderSwap {
    /** Любая стандартная модель брони — нужна, чтобы отличить кастомные модели из модов. */
    static HumanoidModel<?> probe;

    static Player swapped;
    static boolean anySmall;
    static final ItemStack[] real = new ItemStack[LayerLayout.PARTS];
    static final ItemStack[] vanillaView = new ItemStack[LayerLayout.PARTS];
    static final ItemStack[] smallView = new ItemStack[LayerLayout.PARTS];

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onPre(RenderLivingEvent.Pre<?, ?> event) {
        if (swapped != null) restore();
        if (!(event.getEntity() instanceof Player player)) return;

        ArmorLayersData data = ArmorLayersData.get(player);
        if (data == null || !data.hasDisplay()) return;

        NonNullList<ItemStack> armor = player.getInventory().armor;
        anySmall = false;
        for (int part = 0; part < LayerLayout.PARTS; part++) {
            int idx = LayerLayout.armorIndex(part);
            real[part] = armor.get(idx);

            ItemStack shown = data.getDispStack(part);
            int layer = data.getDispLayer(part);

            if (layer < 0 || shown.isEmpty()) {
                vanillaView[part] = ItemStack.EMPTY;
                smallView[part] = ItemStack.EMPTY;
            } else if (layer == 0 || !isScalable(player, shown, part)) {
                vanillaView[part] = shown;
                smallView[part] = ItemStack.EMPTY;
            } else {
                vanillaView[part] = ItemStack.EMPTY;
                smallView[part] = shown;
                anySmall = true;
            }
            armor.set(idx, vanillaView[part]);
        }
        swapped = player;
    }

    @SubscribeEvent
    public static void onPost(RenderLivingEvent.Post<?, ?> event) {
        if (swapped != null && event.getEntity() == swapped) restore();
    }

    /** Страховка: если Post не пришёл (кто-то отменил рендер), возвращаем предметы в конце тика. */
    public static void safetyRestore() {
        if (swapped != null) restore();
    }

    private static void restore() {
        NonNullList<ItemStack> armor = swapped.getInventory().armor;
        for (int part = 0; part < LayerLayout.PARTS; part++) {
            armor.set(LayerLayout.armorIndex(part), real[part]);
        }
        swapped = null;
        anySmall = false;
    }

    /** Уменьшаем только обычную броню. Если у предмета своя модель (из мода) — оставляем как есть. */
    private static boolean isScalable(Player player, ItemStack stack, int part) {
        if (!(stack.getItem() instanceof ArmorItem armorItem)) return false;
        if (armorItem.getEquipmentSlot() != LayerLayout.SLOTS[part]) return false;
        if (probe == null) return false;
        HumanoidModel<?> model = IClientItemExtensions.of(stack)
                .getHumanoidArmorModel(player, stack, armorItem.getEquipmentSlot(), probe);
        return model == probe;
    }

    private ArmorRenderSwap() {}
}
